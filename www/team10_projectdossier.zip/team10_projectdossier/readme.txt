De meeste bestandsnamen spreken voor zich. In de map src is de broncode van het eindproduct te vinden en de map www bevat de website. Het eindproduct bestaat uit twee onderdelen; namelijk een editor en een Minecraft mod.

De editor kan uitgevoerd worden door editor.jar te openen, hiervoor is Java 7 of nieuwer nodig. Om de mod te gebruiken, is het het computerspel Minecraft nodig en daarvoor staan verder aanwijzingen in de gebruikershandleiding.

Voor het geval dat Minecraft niet is geïnstalleerd, is er een testversie toegevoegd die de mod met voorbeelden bevat. Deze is uit te voeren door minecraft.bat of minecraft.sh te openen en hiervoor is JDK 7 of nieuwer nodig. De eerste keer opstarten kan erg lang duren, maar daarna zal dit sneller gaan. Wanneer deze versie gebruikt wordt, is het aan te raden de editor via editor.bat of editor.sh te openen, zodat de bijbehorende locatie voor resourcepacks wordt gebruikt.
