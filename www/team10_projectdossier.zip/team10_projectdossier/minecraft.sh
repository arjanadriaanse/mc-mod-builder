cd forge
./gradlew runClient
cd ..
