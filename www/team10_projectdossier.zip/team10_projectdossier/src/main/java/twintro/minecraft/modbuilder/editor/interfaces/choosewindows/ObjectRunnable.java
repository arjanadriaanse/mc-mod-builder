package twintro.minecraft.modbuilder.editor.interfaces.choosewindows;

public interface ObjectRunnable {
	public void run(Object obj);
}
