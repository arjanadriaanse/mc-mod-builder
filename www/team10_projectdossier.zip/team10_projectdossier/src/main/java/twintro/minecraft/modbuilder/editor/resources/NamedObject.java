package twintro.minecraft.modbuilder.editor.resources;

public abstract class NamedObject {
	public String name;
	
	@Override
	public String toString(){
		return name;
	}
}
