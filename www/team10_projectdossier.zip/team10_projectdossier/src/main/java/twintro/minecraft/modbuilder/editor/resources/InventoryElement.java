package twintro.minecraft.modbuilder.editor.resources;

import twintro.minecraft.modbuilder.data.resources.models.ItemModelResource;

public abstract class InventoryElement extends Element {
	public ItemModelResource itemModel;
}
