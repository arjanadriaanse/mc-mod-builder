java -jar editor.jar "forge/run/resourcepacks"
