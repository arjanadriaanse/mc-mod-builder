package twintro.minecraft.modbuilder.editor.resources;

import javax.swing.ImageIcon;

public class TextureObject extends NamedObject {
	public ImageIcon image;
}
