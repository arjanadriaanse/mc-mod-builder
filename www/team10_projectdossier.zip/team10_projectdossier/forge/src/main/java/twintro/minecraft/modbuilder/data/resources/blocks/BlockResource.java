package twintro.minecraft.modbuilder.data.resources.blocks;

/**
 * The regular block type.
 */
public class BlockResource extends BaseBlockResource {
	public BlockResource() {
		this.type = BlockType.regular;
	}
}
