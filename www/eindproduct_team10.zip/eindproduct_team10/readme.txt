Uitvoeren editor: editor.bat

Uitvoeren Minecraft: minecraft.bat

Source folder: src