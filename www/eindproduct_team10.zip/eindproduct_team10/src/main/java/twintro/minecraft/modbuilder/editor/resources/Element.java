package twintro.minecraft.modbuilder.editor.resources;

import javax.swing.ImageIcon;

public abstract class Element extends NamedObject {
	public abstract ImageIcon getImage();
}
