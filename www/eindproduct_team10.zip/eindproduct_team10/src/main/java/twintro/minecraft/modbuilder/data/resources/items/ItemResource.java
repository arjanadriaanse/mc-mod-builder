package twintro.minecraft.modbuilder.data.resources.items;

/**
 * The regular item type
 */
public class ItemResource extends BaseItemResource {

	public ItemResource() {
		type = ItemType.regular;
	}
}
