package twintro.minecraft.modbuilder.editor.interfaces.helperclasses;

import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class ListPanel extends JPanel {
	public Map<String, ImageIcon> elements;
}
