package example.main;

public class Recipes {
	public static void init(){
	}
}
