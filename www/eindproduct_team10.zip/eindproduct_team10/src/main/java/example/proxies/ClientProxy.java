package example.proxies;

public class ClientProxy extends ServerProxy {
	@Override
	public void init() {
		super.init();
	}
}
