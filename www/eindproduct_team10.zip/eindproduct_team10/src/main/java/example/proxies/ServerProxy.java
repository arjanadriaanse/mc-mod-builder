package example.proxies;

public class ServerProxy {
	public void init() {
		
	}
}
